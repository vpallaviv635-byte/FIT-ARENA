import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";

const app = express();
const PORT = 3000;
const DB_PATH = path.join(process.cwd(), "db.json");

// Initialize simple JSON database if it doesn't exist
if (!fs.existsSync(DB_PATH)) {
  fs.writeFileSync(DB_PATH, JSON.stringify({
    user: {
      username: "athlete",
      email: "athlete@arena.com",
      password: "password123"
    },
    workouts: [],
    hydration: 0,
    points: 0,
    level: 1,
    weight: 75,
    height: 175,
    streak: 0,
    lastWorkoutDate: null,
    posts: [],
    calendar: {}, // { "2026-04-17": true }
    products: [],
    challenges: [],
    friends: [],
    friendRequests: []
  }));
}

app.use(express.json());

// Auth
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ success: false, message: "Email and password required" });
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  
  // Any email and any password will now grant access
  // If it matches the default email, use the stored username, otherwise derive it from email
  const username = data.user.email === email ? data.user.username : email.split('@')[0];
  
  res.json({ 
    success: true, 
    username: username, 
    points: data.points 
  });
});

// Social Feed
app.get("/api/posts", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  res.json(data.posts || []);
});

app.post("/api/posts", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  const newPost = { 
    id: Date.now().toString(), 
    timestamp: new Date().toISOString(),
    likes: 0,
    shares: 0,
    ...req.body 
  };
  data.posts = [newPost, ...(data.posts || [])];
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json(newPost);
});

app.post("/api/posts/:id/like", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  const post = data.posts.find((p: any) => p.id === req.params.id);
  if (post) {
    post.likes += 1;
    fs.writeFileSync(DB_PATH, JSON.stringify(data));
  }
  res.json({ success: true, likes: post?.likes });
});

app.delete("/api/posts/:id", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  data.posts = data.posts.filter((p: any) => p.id !== req.params.id);
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json({ success: true });
});

// Challenges
app.get("/api/challenges", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  res.json(data.challenges || []);
});

app.post("/api/challenges", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  const newChallenge = { 
    id: `c${Date.now()}`, 
    participants: ['you'],
    completed: false,
    ...req.body 
  };
  data.challenges = [...(data.challenges || []), newChallenge];
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json(newChallenge);
});

app.post("/api/challenges/:id/join", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  const challenge = data.challenges.find((c: any) => c.id === req.params.id);
  if (challenge && !challenge.participants.includes('you')) {
    challenge.participants.push('you');
    fs.writeFileSync(DB_PATH, JSON.stringify(data));
  }
  res.json({ success: true });
});

app.delete("/api/challenges/:id", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  data.challenges = (data.challenges || []).filter((c: any) => c.id !== req.params.id);
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json({ success: true });
});

// Friends & Social
app.get("/api/social-data", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  res.json({
    friends: data.friends || [],
    friendRequests: data.friendRequests || []
  });
});

app.post("/api/friend-requests", (req, res) => {
  const { targetUsername } = req.body;
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  
  if (!targetUsername) return res.status(400).json({ message: "Username required" });
  if (targetUsername.toLowerCase() === data.user.username.toLowerCase()) {
    return res.status(400).json({ message: "You cannot friend yourself" });
  }

  const newRequest = {
    id: `req_${Date.now()}`,
    from: targetUsername, // In a real app, this would be the logged in user, but for demo we treat the 'input' as the sender to make it interactive
    timestamp: new Date().toISOString()
  };

  data.friendRequests = [newRequest, ...(data.friendRequests || [])];
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json(newRequest);
});

app.post("/api/friend-requests/:id/accept", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  const requestIndex = data.friendRequests.findIndex((r: any) => r.id === req.params.id);
  
  if (requestIndex !== -1) {
    const request = data.friendRequests[requestIndex];
    const newFriend = {
      username: request.from,
      avatar: `https://picsum.photos/seed/${request.from}/100/100`,
      level: Math.floor(Math.random() * 50) + 1
    };
    
    data.friends = [newFriend, ...(data.friends || [])];
    data.friendRequests.splice(requestIndex, 1);
    fs.writeFileSync(DB_PATH, JSON.stringify(data));
    res.json(newFriend);
  } else {
    res.status(404).json({ message: "Request not found" });
  }
});

app.post("/api/friend-requests/:id/reject", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  data.friendRequests = (data.friendRequests || []).filter((r: any) => r.id !== req.params.id);
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json({ success: true });
});

app.delete("/api/friends/:username", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  data.friends = (data.friends || []).filter((f: any) => f.username !== req.params.username);
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json({ success: true });
});

// Calendar
app.get("/api/calendar", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  res.json(data.calendar || {});
});

app.post("/api/calendar/toggle", (req, res) => {
  const { date } = req.body;
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  if (!data.calendar) data.calendar = {};
  data.calendar[date] = !data.calendar[date];
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json({ success: true, completed: data.calendar[date] });
});

// Products
app.get("/api/products", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  res.json(data.products || []);
});

app.post("/api/products", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  const newProduct = { 
    id: `p${Date.now()}`, 
    ...req.body 
  };
  data.products = [...(data.products || []), newProduct];
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json(newProduct);
});

// API Routes
app.get("/api/data", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  res.json(data);
});

app.post("/api/workouts", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  const newWorkout = { id: Date.now().toString(), ...req.body };
  data.workouts.push(newWorkout);
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json(newWorkout);
});

app.put("/api/workouts/:id", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  const workoutIndex = data.workouts.findIndex((w: any) => w.id === req.params.id);
  if (workoutIndex !== -1) {
    const wasCompleted = data.workouts[workoutIndex].completed;
    const isNowCompleted = req.body.completed;
    
    // Check if transitioning to completed
    if (!wasCompleted && isNowCompleted) {
      data.points += 10;
      
      const today = new Date().toISOString().split('T')[0];
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];

      if (data.lastWorkoutDate !== today) {
        if (data.lastWorkoutDate === yesterdayStr) {
          data.streak = (data.streak || 0) + 1;
        } else {
          data.streak = 1;
        }
        data.lastWorkoutDate = today;
      }
    } else if (wasCompleted && !isNowCompleted) {
      data.points = Math.max(0, data.points - 10);
    }
    
    data.workouts[workoutIndex] = { ...data.workouts[workoutIndex], ...req.body };
    fs.writeFileSync(DB_PATH, JSON.stringify(data));
  }
  res.json({ success: true, points: data.points });
});

app.delete("/api/workouts/:id", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  data.workouts = data.workouts.filter((w: any) => w.id !== req.params.id);
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json({ success: true });
});

app.post("/api/hydration", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  data.hydration = req.body.value;
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json({ success: true });
});

app.post("/api/profile", (req, res) => {
  const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  if (req.body.weight !== undefined) data.weight = Number(req.body.weight);
  if (req.body.height !== undefined) data.height = Number(req.body.height);
  if (req.body.hydration !== undefined) data.hydration = Number(req.body.hydration);
  fs.writeFileSync(DB_PATH, JSON.stringify(data));
  res.json({ success: true, data });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
