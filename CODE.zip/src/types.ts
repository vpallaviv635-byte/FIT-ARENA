export interface Workout {
  id: string;
  title: string;
  category: 'Strength' | 'Cardio' | 'Flexibility' | 'Recovery';
  completed: boolean;
  duration: number; // minutes
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  points: number;
  rank: number;
  avatar: string;
}

export interface UserStats {
  points: number;
  level: number;
  hydration: number; // glasses
  hydrationGoal: number;
  weight: number; // kg
  weeklyProgress: { day: string; value: number }[];
}

export interface Post {
  id: string;
  username: string;
  type: 'image' | 'video' | 'status';
  content: string; // URL or text
  text?: string;
  likes: number;
  shares: number;
  timestamp: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
}

export interface CalendarDay {
  date: string; // YYYY-MM-DD
  completed: boolean;
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  participants: string[];
  tasks: string[];
  points: number;
  completed: boolean;
}

export interface Friend {
  username: string;
  avatar: string;
  level: number;
}

export interface FriendRequest {
  id: string;
  from: string;
  timestamp: string;
}
