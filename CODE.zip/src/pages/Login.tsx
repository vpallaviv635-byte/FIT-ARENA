import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User, Check, Flame, Mail, Lock } from 'lucide-react';

interface LoginProps {
  onLogin: (username: string) => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const result = await res.json();
      if (result.success) {
        onLogin(result.username);
      } else {
        setError(result.message || 'Access Denied');
      }
    } catch (err) {
      setError('Connection Protocol Failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[var(--color-bg-dark)] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-[32px] p-8 space-y-8"
      >
        <div className="flex flex-col items-center text-center space-y-6">
          <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center rotate-6 shadow-[0_0_30px_rgba(217,255,0,0.3)] relative group">
            <User className="text-black w-10 h-10" />
            <div className="absolute -bottom-1 -right-1 bg-black rounded-full p-1 border border-primary">
              <Check className="text-primary w-3 h-3" />
            </div>
          </div>
          
          <div className="space-y-1">
            <h1 className="text-3xl font-black font-display uppercase italic tracking-tight text-white">Arena Access</h1>
            <p className="text-primary text-[10px] font-black uppercase tracking-[0.2em]">Certified Athlete Identity</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 text-center"
            >
              <p className="text-red-500 text-[10px] font-black uppercase tracking-widest animate-pulse">{error}</p>
            </motion.div>
          )}

          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-zinc-500 uppercase px-1 tracking-widest">Email Address</label>
              <div className="relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-primary transition-colors" />
                <input 
                  type="email" 
                  placeholder="EMAIL@EXAMPLE.COM"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full bg-black/40 border border-[var(--color-border)] rounded-2xl pl-12 pr-4 py-4 text-xs font-bold text-white focus:outline-none focus:border-primary/50 transition-all uppercase"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-zinc-500 uppercase px-1 tracking-widest">Passcode</label>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-primary transition-colors" />
                <input 
                  type="password" 
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full bg-black/40 border border-[var(--color-border)] rounded-2xl pl-12 pr-4 py-4 text-xs font-bold text-white focus:outline-none focus:border-primary/50 transition-all"
                />
              </div>
            </div>
          </div>
          
          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-primary text-black font-black uppercase py-5 rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_30px_rgba(217,255,0,0.4)] flex items-center justify-center gap-3 group disabled:opacity-50 disabled:cursor-not-allowed mt-4"
          >
            <span>{loading ? 'Verifying...' : 'Initialize Session'}</span>
            {!loading && <Flame className="w-5 h-5 group-hover:animate-pulse" />}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
