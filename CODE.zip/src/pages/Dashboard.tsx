import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  Droplet, 
  Flame, 
  Box, 
  Plus, 
  Check, 
  LayoutDashboard, 
  User, 
  Settings, 
  LogOut,
  Lock,
  Heart,
  Share2,
  Camera,
  Video,
  Calendar,
  ShoppingCart,
  MessageSquare,
  Search,
  Trash2,
  Rss,
  Link as LinkIcon,
  Users,
  UserPlus,
  UserCheck,
  UserMinus,
  Target,
  CircleDashed,
  ArrowRight
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  ResponsiveContainer, 
  Cell, 
  Tooltip,
  PieChart,
  Pie,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { MOCK_WORKOUTS, MOCK_LEADERBOARD, MOCK_USER_STATS } from '../constants';
import { Workout, Post, Product, Challenge, Friend, FriendRequest } from '../types';
import React, { useState, useEffect, useRef } from 'react';

import WorkoutTimer from '../components/WorkoutTimer';

interface DashboardProps {
  initialUsername: string;
  onLogout: () => void;
}

export default function Dashboard({ initialUsername, onLogout }: DashboardProps) {
  const [username, setUsername] = useState(initialUsername || 'athlete');
  
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [hydration, setHydration] = useState(0);
  const [weight, setWeight] = useState(75);
  const [height, setHeight] = useState(175);
  const [stats, setStats] = useState({ points: 0, level: 0 });
  const [streak, setStreak] = useState(0);
  const [lastWorkoutDate, setLastWorkoutDate] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('Dashboard');
  
  const [posts, setPosts] = useState<Post[]>([]);
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([]);
  const [calendar, setCalendar] = useState<Record<string, boolean>>({});
  const [products, setProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<Product[]>([]);
  const [showPostModal, setShowPostModal] = useState(false);
  const [showChallengeModal, setShowChallengeModal] = useState(false);
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [checkoutData, setCheckoutData] = useState({ fullName: '', address: '', city: '', zip: '', paymentMethod: 'Card' });
  const [newChallenge, setNewChallenge] = useState({ title: '', description: '', tasks: [] as string[], invitation: '' });
  const [postModalData, setPostModalData] = useState({ type: 'image' as 'image' | 'video', url: '', caption: '' });
  
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetch('/api/data')
      .then(res => res.json())
      .then(data => {
        setWorkouts(data.workouts || []);
        setHydration(data.hydration || 0);
        setWeight(data.weight || 75);
        setHeight(data.height || 175);
        setStats({ points: data.points || 0, level: data.level || 1 });
        setCalendar(data.calendar || {});
        setStreak(data.streak || 0);
        setLastWorkoutDate(data.lastWorkoutDate || null);
        setUsername(data.user?.username || initialUsername);
      });
      
    fetch('/api/posts').then(res => res.json()).then(setPosts);
    fetch('/api/challenges').then(res => res.json()).then(setChallenges);
    fetch('/api/social-data').then(res => res.json()).then(data => {
      setFriends(data.friends || []);
      setFriendRequests(data.friendRequests || []);
    });
    fetch('/api/products').then(res => res.json()).then(setProducts);
  }, [initialUsername]);

  const toggleWorkout = async (id: string) => {
    const workout = workouts.find(w => w.id === id);
    if (!workout) return;
    
    const isNowCompleted = !workout.completed;
    const updated = { ...workout, completed: isNowCompleted };
    
    setWorkouts(prev => prev.map(w => w.id === id ? updated : w));
    
    const res = await fetch(`/api/workouts/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ completed: isNowCompleted })
    });
    const result = await res.json();
    if (result.points !== undefined) {
      setStats(prev => ({ ...prev, points: result.points }));
    }
    // Refresh data to get updated streak
    fetch('/api/data').then(res => res.json()).then(data => {
      setStreak(data.streak || 0);
      setLastWorkoutDate(data.lastWorkoutDate || null);
    });
  };

  const deleteWorkout = async (id: string) => {
    setWorkouts(prev => prev.filter(w => w.id !== id));
    await fetch(`/api/workouts/${id}`, { method: 'DELETE' });
  };

  const addWorkout = async (title: string) => {
    const newWorkout = {
      title,
      category: 'Strength',
      completed: false,
      duration: 30,
    };
    
    const res = await fetch('/api/workouts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newWorkout)
    });
    const created = await res.json();
    setWorkouts(prev => [created, ...prev]);
  };

  const updateHydration = async (value: number) => {
    setHydration(value);
    await fetch('/api/hydration', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ value })
    });
  };

  const updateProfile = async (updates: { weight?: number, height?: number, hydration?: number, username?: string }) => {
    if (updates.weight !== undefined) setWeight(updates.weight);
    if (updates.height !== undefined) setHeight(updates.height);
    if (updates.hydration !== undefined) setHydration(updates.hydration);
    if (updates.username !== undefined) setUsername(updates.username);
    
    await fetch('/api/profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
  };

  const addPost = async (type: 'image' | 'video' | 'status', content: string, text?: string) => {
    try {
      const res = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, type, content, text })
      });
      if (!res.ok) throw new Error('UPLOAD_FAILED');
      const newPost = await res.json();
      setPosts(prev => [newPost, ...prev]);
    } catch (err) {
      console.error(err);
      alert('Failed to post to Arena. Please check your connection.');
    }
  };

  const likePost = async (id: string) => {
    setPosts(prev => prev.map(p => p.id === id ? { ...p, likes: p.likes + 1 } : p));
    await fetch(`/api/posts/${id}/like`, { method: 'POST' });
  };

  const sharePost = async (id: string) => {
    setPosts(prev => prev.map(p => p.id === id ? { ...p, shares: (p.shares || 0) + 1 } : p));
  };

  const deletePost = async (id: string) => {
    if (!window.confirm('Erase this broadcast from the Arena?')) return;
    setPosts(prev => prev.filter(p => p.id !== id));
    await fetch(`/api/posts/${id}`, { method: 'DELETE' });
  };

  const createChallenge = async () => {
    if (!newChallenge.title) return;
    const res = await fetch('/api/challenges', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...newChallenge,
        participants: [username, newChallenge.invitation].filter(Boolean)
      })
    });
    const created = await res.json();
    setChallenges(prev => [created, ...prev]);
    setShowChallengeModal(false);
    setNewChallenge({ title: '', description: '', tasks: [], invitation: '' });
  };

  const joinChallenge = async (id: string) => {
    await fetch(`/api/challenges/${id}/join`, { method: 'POST' });
    setChallenges(prev => prev.map(c => c.id === id ? { ...c, participants: [...c.participants, username] } : c));
  };

  const deleteChallenge = async (id: string) => {
    if (!window.confirm('Terminate this challenge?')) return;
    setChallenges(prev => prev.filter(c => c.id !== id));
    await fetch(`/api/challenges/${id}`, { method: 'DELETE' });
  };

  const toggleCalendarDay = async (date: string) => {
    setCalendar(prev => ({ ...prev, [date]: !prev[date] }));
    await fetch('/api/calendar/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ date })
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const content = reader.result as string;
      setPostModalData({ type, url: content, caption: '' });
      setShowPostModal(true);
    };
    reader.readAsDataURL(file);
    // Reset input
    e.target.value = '';
  };

  const handleUrlPostStart = () => {
    setPostModalData({ type: 'image', url: '', caption: '' });
    setShowPostModal(true);
  };

  const submitPost = async () => {
    if (!postModalData.url) return;
    await addPost(postModalData.type, postModalData.url, postModalData.caption);
    setShowPostModal(false);
  };

  const sendFriendRequest = async (targetUsername: string) => {
    // Basic implementation for now
    alert('Request sent to ' + targetUsername);
  };

  const acceptFriendRequest = async (id: string) => {
    setFriendRequests(prev => prev.filter(r => r.id !== id));
  };

  const rejectFriendRequest = async (id: string) => {
    setFriendRequests(prev => prev.filter(r => r.id !== id));
  };

  const unfriend = async (usernameToRemove: string) => {
    setFriends(prev => prev.filter(f => f.username !== usernameToRemove));
  };

  const addToCart = (product: Product) => {
    setCart(prev => [...prev, product]);
  };

  const removeFromCart = (index: number) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  const completedCount = workouts.filter(w => w.completed).length;
  const totalMinutes = workouts.filter(w => w.completed).reduce((sum, w) => sum + w.duration, 0);
  const progressPercent = workouts.length > 0 ? Math.round((completedCount / workouts.length) * 100) : 0;
  const leaderboardLevel = Math.floor(stats.points / 15) + 1;

  const dynamicLeaderboard = [
    { id: 'you', name: username || 'You', points: stats.points, rank: 1, avatar: 'https://picsum.photos/seed/athlete1/100/100' },
    { id: '2', name: 'Zane_Fit', points: Math.max(0, stats.points - 5), rank: 2, avatar: 'https://picsum.photos/seed/athlete2/100/100' },
    { id: '3', name: 'Nova_Prime', points: Math.max(0, stats.points - 12), rank: 3, avatar: 'https://picsum.photos/seed/athlete3/100/100' },
    { id: '4', name: 'Titan_X', points: Math.max(0, stats.points - 20), rank: 4, avatar: 'https://picsum.photos/seed/athlete4/100/100' },
  ].sort((a, b) => b.points - a.points).map((user, idx) => ({ ...user, rank: idx + 1 }));

  const monthlyStats = [
    { name: 'Jan', workouts: 12, hydration: 210, time: 360 },
    { name: 'Feb', workouts: 18, hydration: 240, time: 540 },
    { name: 'Mar', workouts: 15, hydration: 220, time: 450 },
    { name: 'Apr', workouts: completedCount || 0, hydration: hydration * 30 || 180, time: totalMinutes || 0 },
  ];

  return (
    <div className="min-h-screen bg-[var(--color-bg-dark)] flex flex-col md:flex-row">
      {/* Sidebar - Navigation */}
      <aside className="w-full md:w-64 border-b md:border-b-0 md:border-r border-[var(--color-border)] p-6 space-y-8">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center rotate-3">
            <LayoutDashboard className="text-black w-6 h-6" />
          </div>
          <span className="text-2xl font-black font-display tracking-tight uppercase">Arena</span>
        </div>

        <nav className="space-y-4">
          <NavLink icon={LayoutDashboard} label="Dashboard" active={activeTab === 'Dashboard'} onClick={() => setActiveTab('Dashboard')} />
          <NavLink icon={Rss} label="Feed" active={activeTab === 'Social'} onClick={() => setActiveTab('Social')} />
          <NavLink icon={Trophy} label="Leaderboard" active={activeTab === 'Leaderboard'} onClick={() => setActiveTab('Leaderboard')} />
          <NavLink icon={User} label="Profile" active={activeTab === 'Profile'} onClick={() => setActiveTab('Profile')} />
          <NavLink icon={ShoppingCart} label="Shopping" active={activeTab === 'Shopping'} onClick={() => setActiveTab('Shopping')} />
        </nav>

        <div className="pt-8 mt-auto md:fixed md:bottom-6 md:w-52">
          <button 
            onClick={onLogout}
            className="flex items-center gap-3 text-zinc-500 hover:text-red-500 font-bold uppercase text-xs transition-colors w-full text-left"
          >
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 space-y-6 overflow-y-auto w-full">
        {/* Top Bar / Profile */}
        <div className="flex justify-between items-center mb-6">
          <div className="hidden lg:block">
            <h2 className="text-2xl font-black font-display text-white italic">DASHBOARD</h2>
          </div>
          <div className="flex items-center gap-4 bg-[var(--color-card-bg)] border border-[var(--color-border)] px-4 py-2 rounded-full">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-black font-black text-xs">{username[0]?.toUpperCase() || 'U'}</div>
            <div className="flex flex-col">
              <span className="text-xs font-black uppercase leading-tight">{username || 'Athlete One'}</span>
              <span className="text-[10px] font-bold text-zinc-500 uppercase leading-tight">Tier Level {leaderboardLevel}</span>
            </div>
          </div>
        </div>        {/* Bento Dashboard Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 auto-rows-[minmax(200px,auto)]">
          {activeTab === 'Dashboard' && (
            <>
              {/* STATISTICS VIEW (Span 2x1) */}
              <section className="md:col-span-2 bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-[24px] p-6 flex flex-col justify-between">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-black text-zinc-500 uppercase tracking-widest">Arena Activity</h3>
                  <span className="text-[10px] font-black text-primary bg-primary/10 px-2 py-0.5 rounded">+12% vs last week</span>
                </div>
                <div className="flex items-baseline gap-2 mb-4">
                  <span className="text-4xl font-black font-display tracking-tighter">{totalMinutes.toLocaleString()}</span>
                  <span className="text-zinc-500 font-bold text-sm tracking-widest uppercase">MINS</span>
                </div>
                <div className="h-[100px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={MOCK_USER_STATS.weeklyProgress}>
                      <Bar dataKey="value" radius={[4, 4, 4, 4]}>
                        {MOCK_USER_STATS.weeklyProgress.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={entry.value > 50 ? '#d9ff00' : '#27272a'} 
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </section>

              {/* TODO WORKOUT (Span 1x2) */}
              <section className="lg:row-span-2 bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-[24px] overflow-hidden flex flex-col">
                <div className="p-6 border-b border-[var(--color-border)] flex items-center justify-between">
                  <h3 className="text-sm font-black text-zinc-500 uppercase tracking-widest">Workout Today</h3>
                  <Plus className="w-4 h-4 text-zinc-500" />
                </div>
                <div className="p-4 bg-black/40 border-b border-[var(--color-border)]">
                  <input 
                    type="text" 
                    placeholder="New Objective..."
                    className="w-full bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-lg px-3 py-2 text-xs font-bold uppercase focus:outline-none focus:border-primary transition-colors"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && e.currentTarget.value) {
                        addWorkout(e.currentTarget.value);
                        e.currentTarget.value = '';
                      }
                    }}
                  />
                </div>
                <div className="flex-1 overflow-y-auto divide-y divide-[var(--color-border)]">
                  {workouts.map((workout) => (
                    <div key={workout.id} className="p-4 flex items-center gap-3">
                      <button 
                        onClick={() => toggleWorkout(workout.id)}
                        className={`w-5 h-5 rounded border flex items-center justify-center transition-all flex-shrink-0 ${
                          workout.completed 
                          ? 'bg-primary border-primary' 
                          : 'border-zinc-700 bg-black'
                        }`}
                      >
                        {workout.completed && <Check className="w-3 h-3 text-black font-black" />}
                      </button>
                      <div className="min-w-0">
                        <p className={`text-xs font-bold truncate transition-all ${workout.completed ? 'text-zinc-600 line-through' : ''}`}>
                          {workout.title}
                        </p>
                        <p className="text-[10px] font-mono text-zinc-500 uppercase">{workout.duration}m • {workout.category}</p>
                      </div>
                      <button 
                        onClick={() => deleteWorkout(workout.id)}
                        className="ml-auto text-zinc-800 hover:text-red-500 transition-colors p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </section>

              {/* POINTS BOX (Span 1x1) */}
              <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] p-6 rounded-[24px] flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-zinc-500 uppercase tracking-widest">Total XP</span>
                  <Flame className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="text-4xl font-black font-display tracking-tighter">{stats.points.toLocaleString()}</p>
                  <span className="text-[10px] text-primary font-black uppercase bg-primary/10 px-2 py-1 rounded inline-block mt-2">Personal Peak</span>
                </div>
              </div>

              {/* STREAK BOX (Span 1x1) */}
              <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] p-6 rounded-[24px] flex flex-col justify-between group hover:border-primary/50 transition-all">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-zinc-500 uppercase tracking-widest">Active Streak</span>
                  <Flame className={`w-4 h-4 ${streak > 0 ? 'text-primary animate-pulse' : 'text-zinc-700'}`} />
                </div>
                <div>
                  <div className="flex items-baseline gap-2">
                    <p className="text-4xl font-black font-display tracking-tighter">{streak}</p>
                    <span className="text-zinc-500 font-bold text-sm tracking-widest uppercase">DAYS</span>
                  </div>
                  <div className="flex gap-1 mt-3">
                    {[...Array(7)].map((_, i) => (
                      <div 
                        key={i} 
                        className={`hide-mobile h-1 flex-1 rounded-full transition-all duration-1000 ${
                          i < streak % 7 || (streak > 0 && streak % 7 === 0) ? 'bg-primary shadow-[0_0_8px_#d9ff00]' : 'bg-zinc-800'
                        }`} 
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* CALENDAR BAR (Span 1x1) */}
              <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] p-6 rounded-[24px] flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-black text-zinc-500 uppercase tracking-widest">Arena Duty</span>
                  <Calendar className="w-4 h-4 text-zinc-500" />
                </div>
                <div className="grid grid-cols-7 gap-2">
                  {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, i) => {
                    const date = `2026-04-${13 + i}`; // Mock dates for this week
                    const isCompleted = calendar[date];
                    return (
                      <button 
                        key={i}
                        onClick={() => toggleCalendarDay(date)}
                        className={`flex flex-col items-center gap-1 group`}
                      >
                        <span className="text-[8px] font-black text-zinc-600 group-hover:text-zinc-400">{day}</span>
                        <div className={`w-full aspect-square rounded-md border flex items-center justify-center transition-all ${
                          isCompleted ? 'bg-primary border-primary shadow-[0_0_10px_rgba(217,255,0,0.3)]' : 'bg-black border-zinc-800 hover:border-zinc-600'
                        }`}>
                          {isCompleted && <Check className="w-2 h-2 text-black font-black" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
                <p className="mt-auto text-[10px] font-bold text-zinc-500 uppercase tracking-tight italic">Maintain the streak.</p>
              </div>

              {/* HYDRATION (Span 1x1) */}
              <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] p-6 rounded-[24px] flex flex-col justify-between">
                 <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-zinc-500 uppercase tracking-widest">Hydration</span>
                    <Droplet className="w-4 h-4 text-cyan-400" />
                 </div>
                 <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-black font-display tracking-tighter">{hydration}</span>
                      <span className="text-zinc-500 font-bold text-xs uppercase">/ {MOCK_USER_STATS.hydrationGoal} Glasses</span>
                    </div>
                    <div className="grid grid-cols-4 gap-2 mt-4">
                      {[...Array(MOCK_USER_STATS.hydrationGoal)].map((_, i) => (
                        <button 
                          key={i}
                          onClick={() => updateHydration(i < hydration ? i : i + 1)}
                          className={`h-4 rounded border transition-colors ${i < hydration ? 'bg-cyan-500 border-cyan-400' : 'bg-black border-zinc-800'}`}
                        />
                      ))}
                    </div>
                 </div>
              </div>

              {/* WORKOUT TIMER (Span 1x1) */}
              <div className="lg:col-span-1">
                <WorkoutTimer />
              </div>

              <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] p-6 rounded-[24px] flex flex-col justify-between hover:border-primary/50 transition-colors">
                <span className="text-xs font-black text-zinc-500 uppercase tracking-widest">Leaderboard Level</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-black font-display tracking-tighter text-primary">{leaderboardLevel}</span>
                  <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest italic">Global Tier</span>
                </div>
              </div>

              <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] p-6 rounded-[24px] flex flex-col justify-between">
                <span className="text-xs font-black text-zinc-500 uppercase tracking-widest">Daily Goal</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-black font-display tracking-tighter">{progressPercent}%</span>
                  <span className="text-[10px] font-black text-zinc-500 uppercase">COMPLETE</span>
                </div>
              </div>
            </>
          )}

          {activeTab === 'Leaderboard' && (
            <>
              {/* LEADERBOARD VIEW */}
              <section className="lg:col-span-3 lg:row-span-2 bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-[24px] p-8 flex flex-col">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h3 className="text-2xl font-black font-display uppercase italic tracking-tight">Global Ranking</h3>
                    <p className="text-zinc-500 text-xs font-bold uppercase tracking-widest">Compete with the elite athletes</p>
                  </div>
                  <Trophy className="w-10 h-10 text-primary" />
                </div>
                <div className="space-y-4 flex-1">
                  {dynamicLeaderboard.length > 0 ? (
                    dynamicLeaderboard.map((user) => (
                      <div 
                        key={user.id} 
                        className={`flex items-center gap-4 p-4 rounded-2xl border transition-colors ${
                          user.id === 'you' ? 'bg-primary/5 border-primary/20' : 'border-zinc-800 bg-black/40'
                        }`}
                      >
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-black text-sm overflow-hidden border ${
                          user.id === 'you' ? 'border-primary shadow-[0_0_10px_rgba(217,255,0,0.3)]' : 'border-zinc-800'
                        }`}>
                          <img 
                            src={user.avatar} 
                            alt={user.name} 
                            className="w-full h-full object-cover" 
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm font-black uppercase truncate ${user.id === 'you' ? 'text-primary' : ''}`}>{user.name}</p>
                          <p className="text-[10px] font-bold text-zinc-500 uppercase">{user.points.toLocaleString()} XP Points</p>
                        </div>
                        <span className="text-lg font-mono font-black text-primary">#{user.rank}</span>
                      </div>
                    ))
                  ) : (
                    <div className="flex flex-col items-center justify-center h-64 text-zinc-700 space-y-4 opacity-50 bg-black/20 rounded-3xl border border-dashed border-[var(--color-border)]">
                      <Trophy className="w-12 h-12" />
                      <div className="text-center">
                        <p className="text-xs font-black uppercase tracking-widest">Arena Sector Offline</p>
                        <p className="text-[10px] font-bold">Waiting for challengers to enter...</p>
                      </div>
                    </div>
                  )}
                </div>
              </section>

              {/* Side Stats on Leaderboard page */}
              <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] p-6 rounded-[24px] flex flex-col justify-between">
                <span className="text-xs font-black text-zinc-500 uppercase tracking-widest tracking-tighter">Your Position</span>
                <div>
                  <p className="text-5xl font-black font-display tracking-tighter italic text-primary">#{dynamicLeaderboard.find(u => u.id === 'you')?.rank || 1}</p>
                  <p className="text-[10px] text-zinc-500 font-bold uppercase mt-1">Starting the Climb</p>
                </div>
              </div>

              <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] p-6 rounded-[24px] flex flex-col justify-between">
                <span className="text-xs font-black text-zinc-500 uppercase tracking-widest tracking-tighter">Total Points</span>
                <div>
                  <p className="text-5xl font-black font-display tracking-tighter text-white">{stats.points.toLocaleString()}</p>
                  <p className="text-[10px] text-zinc-500 font-bold uppercase mt-1">Current XP</p>
                </div>
              </div>

              {/* CHALLENGES VIEW */}
              <section className="lg:col-span-4 bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-[24px] p-8 space-y-8">
                <div className="flex items-center justify-between border-b border-[var(--color-border)] pb-6">
                  <div>
                    <h3 className="text-2xl font-black font-display uppercase italic tracking-tight text-primary">Arena Challenges</h3>
                    <p className="text-zinc-500 text-xs font-bold uppercase tracking-widest">Deploy custom objectives and target rivals</p>
                  </div>
                  <button 
                    onClick={() => setShowChallengeModal(true)}
                    className="flex items-center gap-2 px-6 py-3 bg-primary text-black rounded-2xl hover:bg-[#ebff00] transition-all font-black uppercase text-[10px] shadow-[0_0_20px_rgba(217,255,0,0.2)]"
                  >
                    <Plus className="w-4 h-4" />
                    Create Challenge
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {challenges.length > 0 ? (
                    challenges.map((challenge) => (
                      <div key={challenge.id} className="bg-black/40 border border-zinc-800 rounded-3xl p-6 group hover:border-primary/40 transition-all relative">
                        <button 
                          onClick={() => deleteChallenge(challenge.id)}
                          className="absolute top-4 right-4 text-zinc-700 hover:text-red-400 p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        
                        <div className="flex items-start justify-between mb-6">
                          <div>
                            <span className="px-2 py-1 bg-primary/10 text-primary text-[8px] font-black uppercase rounded-lg border border-primary/20 tracking-widest">ACTIVE OPS</span>
                            <h4 className="text-lg font-black font-display uppercase italic tracking-tight mt-2">{challenge.title}</h4>
                            <p className="text-xs font-bold text-zinc-500 uppercase mt-1 line-clamp-2">{challenge.description}</p>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <div className="pt-4 border-t border-zinc-800 flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <div className="flex -space-x-2">
                                {challenge.participants.map((p, i) => (
                                  <div key={i} className={`w-8 h-8 rounded-full border-2 border-[#09090b] flex items-center justify-center bg-zinc-800 text-[8px] font-black text-white uppercase`}>
                                    {p.substring(0, 2)}
                                  </div>
                                ))}
                              </div>
                              <span className="text-[10px] font-black text-zinc-500 uppercase">{challenge.participants.length} Deployments</span>
                            </div>
                            
                            {!challenge.participants.includes('you') ? (
                              <button 
                                onClick={() => joinChallenge(challenge.id)}
                                className="px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-[10px] font-black uppercase hover:border-primary hover:text-primary transition-all"
                              >
                                Join Operation
                              </button>
                            ) : (
                              <div className="flex items-center gap-1.5 text-primary text-[10px] font-black uppercase">
                                <Check className="w-4 h-4" />
                                Engaged
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="col-span-2 flex flex-col items-center justify-center py-16 text-zinc-800 bg-black/20 rounded-3xl border-2 border-dashed border-zinc-900">
                       <Target className="w-12 h-12 mb-4 opacity-20" />
                       <p className="text-xs font-black uppercase tracking-widest opacity-40">No Regional Challenges Active</p>
                       <button 
                         onClick={() => setShowChallengeModal(true)}
                         className="mt-6 text-[10px] font-black uppercase text-primary hover:underline"
                       >
                         Start a new operation
                       </button>
                    </div>
                  )}
                </div>
              </section>
            </>
          )}

          {activeTab === 'Social' && (
            <>
              {/* SOCIAL FEED / STATUS BAR (Full Width) */}
              <section className="lg:col-span-4 bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-[24px] p-8 space-y-8">
                <div className="flex items-center justify-between border-b border-[var(--color-border)] pb-6">
                  <div>
                    <h3 className="text-2xl font-black font-display uppercase italic tracking-tight">Arena Social</h3>
                  </div>
                  <div className="flex gap-4">
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      ref={imageInputRef}
                      onChange={(e) => handleFileUpload(e, 'image')}
                    />
                    <input 
                      type="file" 
                      accept="video/*" 
                      className="hidden" 
                      ref={videoInputRef}
                      onChange={(e) => handleFileUpload(e, 'video')}
                    />
                    <button 
                      onClick={() => imageInputRef.current?.click()}
                      className="flex items-center gap-2 px-4 py-2 bg-zinc-900 rounded-xl hover:bg-zinc-800 transition-all text-zinc-400 hover:text-primary active:scale-95"
                    >
                      <Camera className="w-4 h-4" />
                      <span className="text-[10px] font-black uppercase">Post Photo</span>
                    </button>
                    <button 
                      onClick={() => videoInputRef.current?.click()}
                      className="flex items-center gap-2 px-4 py-2 bg-zinc-900 rounded-xl hover:bg-zinc-800 transition-all text-zinc-400 hover:text-primary active:scale-95"
                    >
                      <Video className="w-4 h-4" />
                      <span className="text-[10px] font-black uppercase">Post Video</span>
                    </button>
                    <button 
                      onClick={handleUrlPostStart}
                      className="flex items-center gap-2 px-4 py-2 bg-zinc-900 rounded-xl hover:bg-zinc-800 transition-all text-zinc-400 hover:text-primary active:scale-95 border border-zinc-800"
                    >
                      <LinkIcon className="w-4 h-4" />
                      <span className="text-[10px] font-black uppercase">Post URL</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {posts.map((post) => (
                    <div key={post.id} className="bg-black/20 border border-zinc-900 rounded-2xl p-6 space-y-4 group hover:border-primary/30 transition-all">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-[10px] font-black text-black">
                          {post.username[0].toUpperCase()}
                        </div>
                        <div>
                          <p className="text-[10px] font-black uppercase text-zinc-200">{post.username}</p>
                          <p className="text-[8px] font-bold text-zinc-600 uppercase italic">Active Level {leaderboardLevel}</p>
                        </div>
                        <span className="ml-auto text-[8px] font-bold text-zinc-700 uppercase">{new Date(post.timestamp).toLocaleDateString()}</span>
                        <button 
                          onClick={() => deletePost(post.id)}
                          className="text-zinc-700 hover:text-red-500 transition-colors p-1"
                          title="Delete Post"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                      
                      <div className="aspect-square bg-zinc-900 rounded-2xl overflow-hidden border border-zinc-900 relative">
                        {post.type === 'image' ? (
                          <img 
                            src={post.content} 
                            alt="Post" 
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <video 
                            src={post.content} 
                            className="w-full h-full object-cover" 
                            controls={true}
                            muted 
                            loop 
                          />
                        )}
                      </div>

                      <div className="space-y-4">
                        <p className="text-xs font-bold text-zinc-400 uppercase leading-relaxed tracking-tight">{post.text}</p>
                        <div className="flex items-center gap-4 pt-4 border-t border-zinc-900">
                          <button onClick={() => likePost(post.id)} className="flex items-center gap-1.5 text-zinc-600 hover:text-red-500 transition-colors group/btn">
                            <Heart className={`w-4 h-4 ${post.likes > 0 ? 'fill-red-500 text-red-500' : ''}`} />
                            <span className="text-[10px] font-black tracking-widest">{post.likes}</span>
                          </button>
                          <button onClick={() => sharePost(post.id)} className="flex items-center gap-1.5 text-zinc-600 hover:text-primary transition-colors group/btn">
                            <Share2 className="w-4 h-4" />
                            <span className="text-[10px] font-black tracking-widest">{post.shares || 0}</span>
                          </button>
                          <div className="ml-auto flex items-center gap-1">
                            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                            <span className="text-[8px] font-black text-zinc-700 uppercase">Live in Sector</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* SECTOR CONNECTIONS (FRIENDS) */}
              <section className="lg:col-span-4 grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-[24px] p-8 space-y-6">
                  <div className="flex items-center justify-between border-b border-[var(--color-border)] pb-4">
                    <div>
                      <h4 className="text-xl font-black font-display uppercase italic tracking-tight text-primary">Active Contacts</h4>
                      <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-widest">Verified sector operatives</p>
                    </div>
                    <Users className="w-5 h-5 text-primary" />
                  </div>

                  <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                    {friends.length > 0 ? (
                      friends.map((friend) => (
                        <div key={friend.username} className="flex items-center gap-4 p-3 bg-black/40 border border-zinc-900 rounded-2xl group hover:border-primary/30 transition-all">
                          <img 
                            src={friend.avatar} 
                            alt={friend.username}
                            className="w-10 h-10 rounded-full border border-zinc-800"
                            referrerPolicy="no-referrer"
                          />
                          <div className="flex-1">
                            <p className="text-xs font-black uppercase text-zinc-200">{friend.username}</p>
                            <p className="text-[8px] font-bold text-zinc-600 uppercase">TIER LEVEL {friend.level}</p>
                          </div>
                          <button 
                            onClick={() => unfriend(friend.username)}
                            className="p-2 text-zinc-800 hover:text-red-500 transition-colors"
                            title="Cut Connection"
                          >
                            <UserMinus className="w-4 h-4" />
                          </button>
                        </div>
                      ))
                    ) : (
                      <div className="py-12 text-center space-y-2 opacity-30">
                        <Users className="w-8 h-8 mx-auto text-zinc-700" />
                        <p className="text-[10px] font-black uppercase tracking-widest">Zero Contacts in Range</p>
                      </div>
                    )}
                  </div>

                  <div className="pt-4 border-t border-zinc-800">
                     <div className="relative group">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-primary" />
                        <input 
                          type="text" 
                          placeholder="INPUT USERNAME..."
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              sendFriendRequest(e.currentTarget.value);
                              e.currentTarget.value = '';
                            }
                          }}
                          className="w-full bg-zinc-900/50 border border-zinc-800 rounded-xl pl-12 pr-4 py-3 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:border-primary/50 transition-all"
                        />
                     </div>
                     <p className="text-[8px] font-bold text-zinc-600 uppercase mt-3 px-1">Press Enter to dispatch request</p>
                  </div>
                </div>

                <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-[24px] p-8 space-y-6">
                  <div className="flex items-center justify-between border-b border-[var(--color-border)] pb-4">
                    <div>
                      <h4 className="text-xl font-black font-display uppercase italic tracking-tight text-primary">Pending Admissions</h4>
                      <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-widest">Inbound connection requests</p>
                    </div>
                    <div className="relative">
                      <Rss className="w-5 h-5 text-zinc-500" />
                      {friendRequests.length > 0 && (
                        <span className="absolute -top-1 -right-1 w-2 h-2 bg-primary rounded-full animate-pulse" />
                      )}
                    </div>
                  </div>

                  <div className="space-y-4 max-h-[380px] overflow-y-auto pr-2 custom-scrollbar">
                    {friendRequests.length > 0 ? (
                      friendRequests.map((req) => (
                        <div key={req.id} className="flex items-center gap-4 p-4 bg-zinc-900/40 border border-zinc-800 rounded-2xl animate-in fade-in slide-in-from-right-4 duration-500">
                          <div className="w-10 h-10 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-[10px] font-black text-zinc-400">
                             {req.from[0]?.toUpperCase()}
                          </div>
                          <div className="flex-1">
                            <p className="text-xs font-black uppercase text-zinc-200">{req.from}</p>
                            <p className="text-[8px] font-bold text-zinc-600 uppercase">{new Date(req.timestamp).toLocaleTimeString()}</p>
                          </div>
                          <div className="flex gap-1">
                            <button 
                              onClick={() => acceptFriendRequest(req.id)}
                              className="p-2 bg-primary/10 text-primary hover:bg-primary hover:text-black rounded-lg transition-all"
                            >
                              <UserCheck className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => rejectFriendRequest(req.id)}
                              className="p-2 bg-zinc-800 text-zinc-500 hover:bg-red-500/10 hover:text-red-500 rounded-lg transition-all"
                            >
                              <UserMinus className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="py-16 text-center space-y-2 opacity-30">
                        <CircleDashed className="w-8 h-8 mx-auto text-zinc-700 animate-spin-slow" />
                        <p className="text-[10px] font-black uppercase tracking-widest">Scanning for Inbound Requests...</p>
                      </div>
                    )}
                  </div>
                </div>
              </section>
            </>
          )}

          {activeTab === 'Shopping' && (
            <>
              {/* SHOPPING VIEW */}
              <section className="lg:col-span-3 lg:row-span-2 bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-[24px] p-8 flex flex-col">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                    <div>
                      <h3 className="text-2xl font-black font-display uppercase italic tracking-tight underline decoration-primary decoration-4 underline-offset-8">Arena Supplies</h3>
                      <p className="text-zinc-500 text-xs font-bold uppercase tracking-widest mt-2">Elite gear for elite performers</p>
                    </div>
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                      <div className="relative group">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500 group-focus-within:text-primary transition-colors" />
                        <input 
                          type="text"
                          placeholder="SEARCH GEAR..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="bg-black/40 border border-zinc-800 rounded-xl pl-10 pr-4 py-2 text-[10px] font-black tracking-widest focus:outline-none focus:border-primary/50 transition-all w-full sm:w-48 lg:w-64"
                        />
                      </div>
                      <div className="flex items-center gap-4">
                        <ShoppingCart className="w-10 h-10 text-primary hidden sm:block" />
                      </div>
                    </div>
                  </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {products.filter(p => 
                    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                    p.description.toLowerCase().includes(searchQuery.toLowerCase())
                  ).map((product, idx) => (
                    <div key={product.id} className="bg-black/40 border border-[var(--color-border)] rounded-2xl p-4 space-y-4 hover:border-primary/40 transition-all group relative overflow-hidden">
                      {idx === 0 && (
                        <div className="absolute top-3 left-3 bg-[#ffa41c] text-black text-[8px] font-black uppercase px-2 py-1 rounded-sm z-10 shadow-sm">
                          Best Seller
                        </div>
                      )}
                      <div className="aspect-square bg-zinc-900 rounded-xl overflow-hidden relative">
                        <img 
                          src={product.image} 
                          alt={product.name} 
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-1 mb-1">
                          {[...Array(5)].map((_, i) => (
                            <Trophy key={i} className={`w-2.5 h-2.5 ${i < 4 ? 'text-[#ffa41c] fill-[#ffa41c]' : 'text-zinc-700'}`} />
                          ))}
                          <span className="text-[8px] text-zinc-500 font-bold ml-1">4.8 (2.4k+)</span>
                        </div>
                        <h4 className="text-sm font-black uppercase text-zinc-200 group-hover:text-primary transition-colors">{product.name}</h4>
                        <p className="text-[10px] font-bold text-zinc-600 uppercase line-clamp-2 leading-relaxed">{product.description}</p>
                      </div>
                      <div className="flex flex-col gap-3 pt-2">
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-black font-display text-primary">₹{product.price}</span>
                          <span className="text-[10px] text-zinc-700 font-bold line-through">₹{(product.price * 1.2).toFixed(0)}</span>
                        </div>
                        <div className="flex items-center gap-2">
                           <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                           <div className="w-2.5 h-2.5 rounded-full bg-zinc-800" />
                           <div className="w-2.5 h-2.5 rounded-full bg-white/20" />
                        </div>
                        <button 
                          onClick={() => addToCart(product)}
                          className="w-full bg-primary text-black text-[10px] font-black uppercase py-3 rounded-xl hover:bg-[#ebff00] active:scale-95 transition-all shadow-[0_4px_15px_rgba(217,255,0,0.15)]"
                        >
                          Add to Cart
                        </button>
                        <p className="text-[8px] text-zinc-600 font-bold uppercase text-center italic">Arena Prime • Free 2-Day Delivery</p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] p-6 rounded-[24px] flex flex-col gap-6 lg:row-span-2 overflow-hidden">
                <div className="flex items-center justify-between border-b border-zinc-900 pb-4">
                  <div className="flex items-center gap-2">
                    <ShoppingCart className="w-5 h-5 text-primary" />
                    <span className="text-sm font-black text-white uppercase tracking-tighter">Your Arena Cart</span>
                  </div>
                  <span className="text-[10px] font-black bg-primary text-black px-2 py-0.5 rounded-full">{cart.length}</span>
                </div>

                <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar max-h-[400px]">
                  {cart.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-4">
                      <div className="w-12 h-12 rounded-full bg-zinc-900 flex items-center justify-center mb-3">
                        <Box className="w-5 h-5 text-zinc-700" />
                      </div>
                      <p className="text-[10px] font-black text-zinc-600 uppercase tracking-widest leading-loose">The Arena is empty. Start adding gear!</p>
                    </div>
                  ) : (
                    cart.map((item, idx) => (
                      <div key={`${item.id}-${idx}`} className="flex items-center gap-3 p-3 bg-black/40 border border-zinc-900 rounded-xl group relative overflow-hidden">
                        <div className="w-12 h-12 rounded-lg bg-zinc-900 overflow-hidden shrink-0">
                          <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[10px] font-black text-white uppercase truncate">{item.name}</p>
                          <p className="text-[10px] font-bold text-primary">₹{item.price}</p>
                        </div>
                        <button 
                          onClick={() => removeFromCart(idx)}
                          className="w-8 h-8 rounded-lg bg-zinc-900 text-zinc-700 hover:text-red-500 hover:bg-red-500/10 transition-all flex items-center justify-center shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>

                {cart.length > 0 && (
                  <div className="pt-4 border-t border-zinc-900 space-y-4">
                    <div className="flex items-center justify-between px-1">
                      <span className="text-[10px] font-black text-zinc-500 uppercase">Subtotal</span>
                      <span className="text-xl font-black font-display text-white">₹{cart.reduce((sum, item) => sum + Number(item.price), 0)}</span>
                    </div>
                    <button 
                      onClick={() => setShowCheckoutModal(true)}
                      className="w-full bg-primary text-black font-black uppercase py-4 rounded-xl hover:bg-[#ebff00] transition-all flex items-center justify-center gap-2 shadow-[0_10px_30px_rgba(217,255,0,0.1)]"
                    >
                      Secure Checkout
                    </button>
                  </div>
                )}
              </div>
            </>
          )}

          {activeTab === 'Profile' && (
            <>
              {/* PROFILE VIEW */}
              <section className="lg:col-span-3 lg:row-span-1 bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-[24px] p-8 flex items-center gap-8">
                <div className="w-24 h-24 rounded-[32px] bg-primary flex items-center justify-center text-black text-4xl font-black font-display outline outline-8 outline-black">
                  {username[0]?.toUpperCase() || 'U'}
                </div>
                <div className="space-y-4 flex-1">
                  <div>
                    <h3 className="text-3xl font-black font-display uppercase italic text-white tracking-tight">{username || 'Athlete One'}</h3>
                    <div className="flex gap-2 mt-1">
                      <span className="text-[10px] font-black uppercase text-primary bg-primary/10 px-2 py-1 rounded">Rank: Challenger</span>
                      <span className="text-[10px] font-black uppercase text-zinc-500 bg-zinc-900 px-2 py-1 rounded">Tier {leaderboardLevel}</span>
                      <span className={`text-[10px] font-black uppercase px-2 py-1 rounded ${streak > 0 ? 'bg-orange-500/10 text-orange-500' : 'bg-zinc-900 text-zinc-500'}`}>
                        Streak: {streak} Days
                      </span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-zinc-500 uppercase">Weight (KG)</label>
                      <input 
                        type="number" 
                        value={weight}
                        onChange={(e) => updateProfile({ weight: Number(e.target.value) })}
                        className="w-full bg-black border border-[var(--color-border)] rounded-lg px-3 py-2 text-sm font-black focus:outline-none focus:border-primary"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-zinc-500 uppercase">Height (CM)</label>
                      <input 
                        type="number" 
                        value={height}
                        onChange={(e) => updateProfile({ height: Number(e.target.value) })}
                        className="w-full bg-black border border-[var(--color-border)] rounded-lg px-3 py-2 text-sm font-black focus:outline-none focus:border-primary"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-zinc-500 uppercase">Hydration</label>
                      <input 
                        type="number" 
                        value={hydration}
                        onChange={(e) => updateProfile({ hydration: Number(e.target.value) })}
                        className="w-full bg-black border border-[var(--color-border)] rounded-lg px-3 py-2 text-sm font-black focus:outline-none focus:border-primary"
                      />
                    </div>
                  </div>
                </div>
              </section>

              <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] p-6 rounded-[24px] flex flex-col justify-between">
                <span className="text-xs font-black text-zinc-500 uppercase tracking-widest tracking-tighter">Current BMI</span>
                <div className="flex flex-col">
                  <p className="text-4xl font-black font-display tracking-tighter text-white">
                    {(weight / Math.pow(height / 100, 2)).toFixed(1)}
                  </p>
                  <p className="text-[10px] font-black uppercase text-primary mt-1">
                    {(() => {
                      const bmi = weight / Math.pow(height / 100, 2);
                      if (bmi < 18.5) return 'Underweight';
                      if (bmi < 25) return 'Normal Weight';
                      if (bmi < 30) return 'Overweight';
                      return 'Obese';
                    })()}
                  </p>
                </div>
              </div>

              <section className="lg:col-span-4 bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-[24px] p-8">
                <h3 className="text-sm font-black text-zinc-500 uppercase tracking-widest mb-6">Performance History</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
                   <div className="space-y-1">
                      <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Weight</p>
                      <p className="text-xl font-black font-display">{weight} KG</p>
                   </div>
                   <div className="space-y-1">
                      <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Completed</p>
                      <p className="text-xl font-black font-display">{completedCount}</p>
                   </div>
                   <div className="space-y-1">
                      <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Hydration</p>
                      <p className="text-xl font-black font-display">{hydration} Glasses</p>
                   </div>
                   <div className="space-y-1">
                      <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Total Time</p>
                      <p className="text-xl font-black font-display">{totalMinutes} MINS</p>
                   </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 border-t border-zinc-900 pt-8 mt-8">
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-sm font-black text-zinc-500 uppercase tracking-widest">Monthly Growth</h3>
                        <p className="text-[10px] text-zinc-600 font-bold uppercase mt-1">Activity over time</p>
                      </div>
                      <Flame className="w-5 h-5 text-primary" />
                    </div>
                    <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={monthlyStats}>
                          <defs>
                            <linearGradient id="colorTime" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#d9ff00" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#d9ff00" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <XAxis 
                            dataKey="name" 
                            axisLine={false} 
                            tickLine={false} 
                            tick={{ fill: '#71717a', fontSize: 10, fontWeight: 900 }} 
                            dy={10}
                          />
                          <Tooltip 
                            contentStyle={{ background: '#09090b', border: '1px solid #27272a', borderRadius: '12px' }}
                            labelStyle={{ color: '#d9ff00', fontWeight: 900, textTransform: 'uppercase', fontSize: '10px' }}
                            itemStyle={{ color: '#fff', fontSize: '10px', fontWeight: 700 }}
                          />
                          <Area 
                            type="monotone" 
                            dataKey="time" 
                            stroke="#d9ff00" 
                            strokeWidth={3}
                            fillOpacity={1} 
                            fill="url(#colorTime)" 
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <h3 className="text-sm font-black text-zinc-500 uppercase tracking-widest text-center">Consistency Ratio</h3>
                    <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={[
                              { name: 'Active Days', value: 12 },
                              { name: 'Recovery Days', value: 16 }
                            ]}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            <Cell fill="#d9ff00" stroke="none" />
                            <Cell fill="#18181b" stroke="none" />
                          </Pie>
                          <Tooltip 
                            contentStyle={{ background: '#09090b', border: '1px solid #27272a', borderRadius: '12px' }}
                            itemStyle={{ color: '#fff', fontSize: '10px', fontWeight: 900, textTransform: 'uppercase' }}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="flex items-center justify-center gap-8">
                       <div className="flex items-center gap-2">
                         <div className="w-3 h-3 rounded-full bg-primary" />
                         <span className="text-[10px] font-black text-zinc-500 uppercase">Active (12)</span>
                       </div>
                       <div className="flex items-center gap-2">
                         <div className="w-3 h-3 rounded-full bg-zinc-900" />
                         <span className="text-[10px] font-black text-zinc-500 uppercase">Rest (16)</span>
                       </div>
                    </div>
                  </div>
                </div>
              </section>
            </>
          )}
        </div>

        {/* Custom Post Modal */}
        <AnimatePresence>
          {showPostModal && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/90 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 20 }}
                className="bg-[#09090b] border border-zinc-800 rounded-[32px] w-full max-w-md overflow-hidden shadow-[0_30px_60px_-15px_rgba(0,0,0,0.5)]"
              >
                <div className="p-8 space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-black font-display italic uppercase tracking-tight">Arena Broadcast</h3>
                      <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mt-1">Configure your status update</p>
                    </div>
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <Rss className="w-5 h-5 text-primary" />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex bg-zinc-900 rounded-2xl p-1">
                      <button 
                        onClick={() => setPostModalData(prev => ({ ...prev, type: 'image' }))}
                        className={`flex-1 py-3 px-4 rounded-xl text-[10px] font-black uppercase transition-all ${postModalData.type === 'image' ? 'bg-primary text-black' : 'text-zinc-500 hover:text-zinc-300'}`}
                      >
                        Photo
                      </button>
                      <button 
                        onClick={() => setPostModalData(prev => ({ ...prev, type: 'video' }))}
                        className={`flex-1 py-3 px-4 rounded-xl text-[10px] font-black uppercase transition-all ${postModalData.type === 'video' ? 'bg-primary text-black' : 'text-zinc-500 hover:text-zinc-300'}`}
                      >
                        Video
                      </button>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-zinc-500 uppercase px-1">Media URL</label>
                      <div className="relative">
                        <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                        <input 
                          type="text" 
                          placeholder="PASTE URL HERE..."
                          value={postModalData.url}
                          onChange={(e) => setPostModalData(prev => ({ ...prev, url: e.target.value }))}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl pl-12 pr-4 py-4 text-xs font-bold text-white focus:outline-none focus:border-primary/50 transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-zinc-500 uppercase px-1">Caption</label>
                      <div className="relative">
                        <MessageSquare className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                        <input 
                          type="text" 
                          placeholder="ELITE PROGRESS..."
                          value={postModalData.caption}
                          onChange={(e) => setPostModalData(prev => ({ ...prev, caption: e.target.value }))}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl pl-12 pr-4 py-4 text-xs font-bold text-white focus:outline-none focus:border-primary/50 transition-all"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-2">
                    <button 
                      onClick={() => setShowPostModal(false)}
                      className="flex-1 py-4 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 text-[10px] font-black uppercase rounded-2xl transition-all"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={submitPost}
                      disabled={!postModalData.url}
                      className="flex-1 py-4 bg-primary hover:bg-[#ebff00] disabled:opacity-50 disabled:hover:bg-primary text-black text-[10px] font-black uppercase rounded-2xl transition-all"
                    >
                      Initialize Post
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Custom Challenge Modal */}
        <AnimatePresence>
          {showChallengeModal && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/90 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 20 }}
                className="bg-[#09090b] border border-zinc-800 rounded-[32px] w-full max-w-md overflow-hidden shadow-[0_30px_60px_-15px_rgba(0,0,0,0.5)]"
              >
                <div className="p-8 space-y-6">
                  <div className="flex items-center justify-between outline-none">
                    <div>
                      <h3 className="text-xl font-black font-display italic uppercase tracking-tight text-primary">Challenge Briefing</h3>
                      <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mt-1">Define objective parameters</p>
                    </div>
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <Target className="w-5 h-5 text-primary" />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-zinc-500 uppercase px-1">Challenge Name</label>
                      <input 
                        type="text" 
                        placeholder="E.G., 100 PUSHUP GAUNTLET"
                        value={newChallenge.title}
                        onChange={(e) => setNewChallenge(prev => ({ ...prev, title: e.target.value }))}
                        className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl px-4 py-4 text-xs font-bold text-white focus:outline-none focus:border-primary/50 transition-all uppercase"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-zinc-500 uppercase px-1">Invite Rival (Username)</label>
                      <div className="relative">
                        <Users className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                        <input 
                          type="text" 
                          placeholder="E.G., Pro_Athlete"
                          value={newChallenge.invitation}
                          onChange={(e) => setNewChallenge(prev => ({ ...prev, invitation: e.target.value }))}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl pl-12 pr-4 py-4 text-xs font-bold text-white focus:outline-none focus:border-primary/50 transition-all uppercase"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-2">
                    <button 
                      onClick={() => setShowChallengeModal(false)}
                      className="flex-1 py-4 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 text-[10px] font-black uppercase rounded-2xl transition-all"
                    >
                      Abort
                    </button>
                    <button 
                      onClick={createChallenge}
                      disabled={!newChallenge.title}
                      className="flex-1 py-4 bg-primary hover:bg-[#ebff00] disabled:opacity-50 disabled:hover:bg-primary text-black text-[10px] font-black uppercase rounded-2xl transition-all shadow-[0_10px_20px_rgba(217,255,0,0.15)]"
                    >
                      Authorize Challenge
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Checkout Modal */}
        <AnimatePresence>
          {showCheckoutModal && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-xl flex items-center justify-center p-6"
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                className="w-full max-w-lg bg-[var(--color-card-bg)] border border-[var(--color-border)] rounded-[40px] overflow-hidden shadow-[0_0_100px_rgba(217,255,0,0.1)]"
              >
                <div className="p-8 space-y-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-3xl font-black font-display uppercase italic tracking-tighter">SECURE DISPATCH</h3>
                      <p className="text-primary text-[10px] font-black uppercase tracking-[0.2em]">Finalizing Arena Supply Chain</p>
                    </div>
                    <button 
                      onClick={() => setShowCheckoutModal(false)}
                      className="w-12 h-12 rounded-full border border-zinc-900 flex items-center justify-center text-zinc-500 hover:text-white transition-colors"
                    >
                      <Plus className="w-6 h-6 rotate-45" />
                    </button>
                  </div>

                  <div className="space-y-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-zinc-500 uppercase px-1 tracking-widest">Full Name / Agent ID</label>
                        <input 
                          type="text" 
                          placeholder="ENTER NAME"
                          value={checkoutData.fullName}
                          onChange={(e) => setCheckoutData({...checkoutData, fullName: e.target.value})}
                          className="w-full bg-black/50 border border-zinc-800 rounded-2xl px-5 py-4 text-xs font-bold text-white focus:outline-none focus:border-primary transition-all uppercase"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-zinc-500 uppercase px-1 tracking-widest">Sector Address</label>
                        <input 
                          type="text" 
                          placeholder="STREET & NUMBER"
                          value={checkoutData.address}
                          onChange={(e) => setCheckoutData({...checkoutData, address: e.target.value})}
                          className="w-full bg-black/50 border border-zinc-800 rounded-2xl px-5 py-4 text-xs font-bold text-white focus:outline-none focus:border-primary transition-all uppercase"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-zinc-500 uppercase px-1 tracking-widest">City / Zone</label>
                          <input 
                            type="text" 
                            placeholder="CITY"
                            value={checkoutData.city}
                            onChange={(e) => setCheckoutData({...checkoutData, city: e.target.value})}
                            className="w-full bg-black/50 border border-zinc-800 rounded-2xl px-5 py-4 text-xs font-bold text-white focus:outline-none focus:border-primary transition-all uppercase"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-zinc-500 uppercase px-1 tracking-widest">Zip / Data Code</label>
                          <input 
                            type="text" 
                            placeholder="ZIP CODE"
                            value={checkoutData.zip}
                            onChange={(e) => setCheckoutData({...checkoutData, zip: e.target.value})}
                            className="w-full bg-black/50 border border-zinc-800 rounded-2xl px-5 py-4 text-xs font-bold text-white focus:outline-none focus:border-primary transition-all uppercase"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-zinc-500 uppercase px-1 tracking-widest">Transaction Hub</label>
                      <div className="grid grid-cols-2 gap-3">
                        {['Card', 'UPI', 'Crypto'].map((method) => (
                          <button
                            key={method}
                            onClick={() => setCheckoutData({...checkoutData, paymentMethod: method})}
                            className={`py-3 rounded-xl border font-black text-[10px] uppercase transition-all ${
                              checkoutData.paymentMethod === method 
                                ? 'bg-primary text-black border-primary' 
                                : 'bg-black/20 text-zinc-500 border-zinc-900 hover:border-zinc-700'
                            }`}
                          >
                            {method} Gateway
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="bg-black/80 rounded-3xl p-6 border border-zinc-900">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-black text-zinc-600 uppercase">Arena Logistics</span>
                        <span className="text-[10px] font-black text-primary uppercase">Calculated</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xl font-black uppercase italic tracking-tighter">Total Liability</span>
                        <span className="text-2xl font-black font-display text-primary">₹{cart.reduce((sum, item) => sum + Number(item.price), 0)}</span>
                      </div>
                    </div>

                    <button 
                      onClick={() => {
                        alert('Order Authorized! Dispatching Arena Supplies.');
                        setCart([]);
                        setShowCheckoutModal(false);
                      }}
                      disabled={!checkoutData.fullName || !checkoutData.address}
                      className="w-full bg-primary text-black font-black uppercase py-5 rounded-3xl hover:bg-[#ebff00] disabled:opacity-30 transition-all shadow-[0_20px_40px_rgba(217,255,0,0.2)] flex items-center justify-center gap-3"
                    >
                      <span>Authorize Payment & Dispatch</span>
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

function NavLink({ icon: Icon, label, active = false, onClick }: { icon: any, label: string, active?: boolean, onClick?: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex items-center gap-3 w-full p-4 rounded-xl transition-all ${
        active ? 'bg-primary text-black' : 'text-zinc-500 hover:bg-zinc-900 hover:text-white'
      }`}
    >
      <Icon className="w-5 h-5" />
      <span className="font-black uppercase text-xs tracking-wider">{label}</span>
    </button>
  );
}

function StatCard({ label, value, icon: Icon, color, subtitle }: { label: string, value: string, icon: any, color: string, subtitle: string }) {
  return (
    <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] p-5 rounded-2xl relative overflow-hidden group hover:border-primary/50 transition-colors">
      <div className="flex items-center justify-between relative z-10">
        <span className="text-[10px] uppercase font-black text-zinc-500 tracking-wider group-hover:text-zinc-400">{label}</span>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <div className="mt-2 relative z-10">
        <p className="text-3xl font-black font-display tracking-tight">{value}</p>
        <p className="text-[10px] text-zinc-600 font-bold mt-1 group-hover:text-zinc-400">{subtitle}</p>
      </div>
      {/* Absolute decorative background text */}
      <span className="absolute -bottom-2 -right-2 text-4xl font-black italic opacity-[0.03] select-none uppercase">{label}</span>
    </div>
  );
}
