import { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Timer as TimerIcon } from 'lucide-react';

export default function WorkoutTimer() {
  const [time, setTime] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isActive) {
      timerRef.current = setInterval(() => {
        setTime((prevTime) => prevTime + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive]);

  const toggleTimer = () => setIsActive(!isActive);
  const resetTimer = () => {
    setIsActive(false);
    setTime(0);
  };

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return [hrs, mins, secs]
      .map((val) => val.toString().padStart(2, '0'))
      .join(':');
  };

  return (
    <div className="bg-[var(--color-card-bg)] border border-[var(--color-border)] p-6 rounded-[24px] flex flex-col justify-between group hover:border-primary/50 transition-colors h-full">
      <div className="flex items-center justify-between">
        <span className="text-xs font-black text-zinc-500 uppercase tracking-widest">Session Timer</span>
        <TimerIcon className={`w-4 h-4 ${isActive ? 'text-primary animate-pulse' : 'text-zinc-600'}`} />
      </div>
      
      <div className="my-2">
        <p className="text-4xl font-black font-mono tracking-tighter text-white tabular-nums">
          {formatTime(time)}
        </p>
      </div>

      <div className="flex gap-2">
        <button
          onClick={toggleTimer}
          className={`flex-1 py-2 rounded-xl flex items-center justify-center transition-all active:scale-95 ${
            isActive 
            ? 'bg-zinc-800 text-white hover:bg-zinc-700' 
            : 'bg-primary text-black hover:bg-[#ebff00] font-black'
          }`}
        >
          {isActive ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
        </button>
        <button
          onClick={resetTimer}
          className="px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-400 hover:text-white hover:border-zinc-700 transition-all active:scale-95"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
