import { Workout, LeaderboardEntry, UserStats } from './types';

export const MOCK_WORKOUTS: Workout[] = [];

export const MOCK_LEADERBOARD: LeaderboardEntry[] = [];

export const MOCK_USER_STATS: UserStats = {
  points: 0,
  level: 1,
  hydration: 0,
  hydrationGoal: 8,
  weight: 75,
  weeklyProgress: [
    { day: 'Mon', value: 0 },
    { day: 'Tue', value: 0 },
    { day: 'Wed', value: 0 },
    { day: 'Thu', value: 0 },
    { day: 'Fri', value: 0 },
    { day: 'Sat', value: 0 },
    { day: 'Sun', value: 0 },
  ],
};
